#include "labs/shell.h"
#include "labs/vgatext.h"

//
// initialize shellstate
//
void shell_init(shellstate_t &state)
{
  state.bufferPos = 0;
  state.PreviousCommandSize = 0;
  state.ShellCommandSize = 0;
  state.CommandOutputSize = 0;
  // key m not working
  char *keys[] = {
      "esc",
      "1",
      "2",
      "3",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "0",
      "-",
      "=",
      "back",
      "tab",
      "q",
      "w",
      "e",
      "r",
      "t",
      "y",
      "u",
      "i",
      "o",
      "p",
      "[",
      "]",
      "entr",
      "ctrl",
      "a",
      "s",
      "d",
      "f",
      "g",
      "h",
      "j",
      "k",
      "l",
      ";",
      "'",
      " ",
      "shft",
      "up",
      "down",
      "left",
      "right",
      "z",
      "x",
      "c",
      "v",
      "b",
      "n",
      "m",
  };
  char *scancode[] = {
      "01",
      "02",
      "03",
      "04",
      "05",
      "06",
      "07",
      "08",
      "09",
      "0a",
      "0b",
      "0c",
      "0d",
      "0e",
      "0f",
      "10",
      "11",
      "12",
      "13",
      "14",
      "15",
      "16",
      "17",
      "18",
      "19",
      "1a",
      "1b",
      "1c",
      "1d",
      "1e",
      "1f",
      "20",
      "21",
      "22",
      "23",
      "24",
      "25",
      "26",
      "27",
      "28",
      "39",
      "2a",
      "48",
      "50",
      "4b",
      "4d",
      "2c",
      "2d",
      "2e",
      "2f",
      "30",
      "31",
      "32",
  };

  for (int i = 0; i < 53; i++)
  {
    state.keys[i] = keys[i];
    state.scancode[i] = scancode[i];
  }
  state.cursorLine = 0;
  for (int i = 0; i < SHELL_BUFFER_SIZE; i++)
  {
    for (int j = 0; j < SHELL_BUFFER_LEN; j++)
      state.out_buffer[i][j] = ' ';
  }
}

//
// handle keyboard event.
// key is in scancode format.
// For ex:
// scancode for following keys are:
//
//      +----------+-----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//      | keys     | esc |  1 |  2 |  3 |  4 |  5 |  6 |  7 |  8 |  9 |  0 |  - |  = |back|
//      +----------+-----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//      | scancode | 01  | 02 | 03 | 04 | 05 | 06 | 07 | 08 | 09 | 0a | 0b | 0c | 0d | 0e |
//      +----------+-----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//
//      +----------+-----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//      | keys     | tab |  q |  w |  e |  r |  t |  y |  u |  i |  o |  p |  [ |  ] |entr|
//      +----------+-----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//      | scancode | 0f  | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 1a | 1b | 1c |
//      +----------+-----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//
//      +----------+-----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//      | keys     |ctrl |  a |  s |  d |  f |  g |  h |  j |  k |  l |  ; |  ' |    |shft|
//      +----------+-----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//      | scancode | 1d  | 1e | 1f | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 2a |
//      +----------+-----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//
// so and so..
//
// - restrict yourself to: 0-9, a-z, esc, enter, arrows
// - ignore other keys like shift, control keys
// - only handle the keys which you're interested in
// - for example, you may want to handle up(0x48),down(0x50) arrow keys for menu.
//

// ctrl
// c

char *shellstate_t::scancode_to_key(uint8_t scankey)
{
  // hoh_debug("scankey: "<<scankey);
  // hoh_debug("scankey: "<<hex2char(scankey));
  // hoh_debug("scankey: "<<hex2char(scankey/16));

  char val[2];
  val[1] = hex2char(scankey);
  val[0] = hex2char(scankey / 16);

  // hoh_debug("val: "<<val);
  // hoh_debug("val: "<<val[0]);
  // hoh_debug("val: "<<val[1]);

  for (int i = 0; i < 53; i++)
  {

    // hoh_debug_nl("scancode: "<<scancode[i]);
    // hoh_debug_nl("key: "<<keys[i]);

    if (val[0] == scancode[i][0] && val[1] == scancode[i][1])
    {
      return keys[i];
    }
  }

  return "";
}

void shell_update(uint8_t scankey, shellstate_t &stateinout)
{

  hoh_debug("Got: " << unsigned(scankey));
  stateinout.increment_key_presses();
  hoh_debug("Key Presses: " << unsigned(stateinout.numKeysPressed));
  // add the scankey to buffer

  char *key = stateinout.scancode_to_key(scankey);
  int val = 0;
  hoh_debug("key: " << key);
  if(key == "back" && stateinout.bufferPos>0)
  {
    hoh_debug("backspace");
    char *x = "";
    stateinout.buffer[stateinout.bufferPos-1] = *x;
    stateinout.bufferPos-=1;
    if(stateinout.bufferPos<0)stateinout.bufferPos=0;
  }
  else if(key!="back" && key!="up" && key!="down" && key!="ctrl" && key!="tab" && key!="left" && key!="right")
  {
    for (int i = stateinout.bufferPos; *key; i++, key++)
    {
      val++;
      stateinout.buffer[i] = *key;
    }
    stateinout.bufferPos += val;
  }
  

  hoh_debug("val: " << val);
  hoh_debug("bufferPos: " << stateinout.bufferPos);
  hoh_debug("buffer: " << stateinout.buffer);
}

//
// do computation
//

// CUSTOM
int fibonacci(int n)
{
  if (n == 0)
  {
    return 0;
  }
  if (n == 1)
  {
    return 1;
  }
  int x = 0;
  int y = 1;
  for (int i = 2; i <= n; i++)
  {
    int temp = x;
    x = y;
    y += temp;
  }
  return y;
}

// CUSTOM
int factorial(int n)
{
  int ans = 1;
  for (int i = 2; i <= n; i++)
  {
    ans *= i;
  }
  return ans;
}

// CUSTOM
int rigourousTesting(int n)
{
  int ans = 1;
  for (int i = 2; i <= 200000000; i++)
  {
    ans = factorial(n);
    if (i % 100000 == 0)
    {
      hoh_debug("i: " << i);
    }
  }
  return ans;
}

// Shell
void shell_step(shellstate_t &stateinout)
{
  if (stateinout.bufferPos == 0)
  {
    char *x = "";
    for (int i = 0; i < 100; i++)
    {
      stateinout.ShellCommand[i] = *x;
    }
    for (int i = 0; i < 100; i++)
    {
      stateinout.CommandOutput[i] = *x;
    }
    for (int i = 0; i < 100; i++)
    {
      stateinout.PreviousCommand[i] = *x;
    }
  }
  int temp = stateinout.bufferPos;
  if (stateinout.bufferPos >= 4 && stateinout.buffer[temp - 1] == 'r' && stateinout.buffer[temp - 2] == 't' && stateinout.buffer[temp - 3] == 'n' && stateinout.buffer[temp - 4] == 'e')
  {
    stateinout.bufferPos -= 4;
    hoh_debug("buffer: " << stateinout.buffer);
    // stateinout.out_buffer[stateinout.cursorLine++] = stateinout.buffer;
    if (stateinout.bufferPos >= 4 && stateinout.buffer[0] == 'e' && stateinout.buffer[1] == 'c' && stateinout.buffer[2] == 'h' && stateinout.buffer[3] == 'o')
    {
      for (int i = 5; i < stateinout.bufferPos; i++)
      {
        stateinout.renderingStringSize += 1;
        stateinout.renderingString[i - 5] = stateinout.buffer[i];
      }
    }
    else if (stateinout.bufferPos >= 4 && stateinout.buffer[0] == 'f' && stateinout.buffer[1] == 'i' && stateinout.buffer[2] == 'b' && stateinout.buffer[3] == ' ')
    {
      bool valid = true;
      uint32_t val = 0;
      for (int i = 4; i < stateinout.bufferPos; i++)
      {
        if (stateinout.buffer[i] < '0' || stateinout.buffer[i] > '9')
        {
          valid = false;
          break;
        }
        val = val * 10 + (stateinout.buffer[i] - '0');
      }

      if (!valid)
      {
        hoh_debug("Invalid input");
      }
      else
      {
        int ans = fibonacci(val);

        hoh_debug("ANS: " << ans);

        char p[100];
        if (ans == 0)
        {
          p[0] = '0';
          p[1] = '\0';
        }
        else
        {
          int i = 0;
          while (ans != 0)
          {
            p[i++] = ans % 10 + '0';
            ans /= 10;
          }
          p[i] = '\0';
          for (int j = 0; j < i; j++)
          {
            stateinout.renderingStringSize += 1;
            stateinout.renderingString[j] = p[i - j - 1];
          }
          // stateinout.bufferPos = 0;
        }
      }
    }

    else if (stateinout.bufferPos >= 4 && stateinout.buffer[0] == 'e' && stateinout.buffer[1] == 'x' && stateinout.buffer[2] == 'i' && stateinout.buffer[3] == 't')
    {
      char *p = "Press Ctrl+Alt+Q";
      for (int loc = 0; *p; loc++, p++)
      {
        stateinout.renderingString[loc] = *p;
        stateinout.renderingStringSize += 1;
      }
    }

    // Look for space between fact i.e. function and argument
    else if (stateinout.bufferPos >= 5 && stateinout.buffer[0] == 'f' && stateinout.buffer[1] == 'a' && stateinout.buffer[2] == 'c' && stateinout.buffer[3] == 't' && stateinout.buffer[4] == ' ')
    {
      bool valid = true;
      uint32_t val = 0;

      // Look for space between fact i.e. function and argument
      for (int i = 5; i < stateinout.bufferPos; i++)
      {
        if (stateinout.buffer[i] < '0' || stateinout.buffer[i] > '9')
        {
          valid = false;
          break;
        }
        val = val * 10 + (stateinout.buffer[i] - '0');
      }
      hoh_debug("VAL: " << val);
      if (!valid)
      {
        hoh_debug("Invalid input");
        // stateinout.renderingString = "Invalid input";
      }
      else
      {
        int ans = factorial(val);

        hoh_debug("ANS: " << ans);

        char p[100];
        if (ans == 0)
        {
          p[0] = '0';
          p[1] = '\0';
        }
        else
        {
          int i = 0;
          while (ans != 0)
          {
            p[i++] = ans % 10 + '0';
            ans /= 10;
          }
          p[i] = '\0';
          for (int j = 0; j < i; j++)
          {
            stateinout.renderingStringSize += 1;
            stateinout.renderingString[j] = p[i - j - 1];
          }
        }
      }
    }

    else if (stateinout.bufferPos >= 6 && stateinout.buffer[0] == 'r' && stateinout.buffer[1] == 't' && stateinout.buffer[2] == 'e' && stateinout.buffer[3] == 's' && stateinout.buffer[4] == 't' && stateinout.buffer[5] == ' ')
    {
      bool valid = true;
      uint32_t val = 0;

      // Look for space between fact i.e. function and argument
      for (int i = 6; i < stateinout.bufferPos; i++)
      {
        if (stateinout.buffer[i] < '0' || stateinout.buffer[i] > '9')
        {
          valid = false;
          break;
        }
        val = val * 10 + (stateinout.buffer[i] - '0');
      }
      hoh_debug("VAL: " << val);
      if (!valid)
      {
        hoh_debug("Invalid input");
        // stateinout.renderingString = "Invalid input";
      }
      else
      {
        if (val > 10)
          val = 10;
        int ans = rigourousTesting(val);

        hoh_debug("ANS: " << ans);

        char p[100];
        if (ans == 0)
        {
          p[0] = '0';
          p[1] = '\0';
        }
        else
        {
          int i = 0;
          while (ans != 0)
          {
            p[i++] = ans % 10 + '0';
            ans /= 10;
          }
          p[i] = '\0';
          for (int j = 0; j < i; j++)
          {
            stateinout.renderingStringSize += 1;
            stateinout.renderingString[j] = p[i - j - 1];
          }
        }
      }
    }

    else if (stateinout.bufferPos == 2 && stateinout.buffer[0] == 'u' && stateinout.buffer[1] == 'p')
    {
      // Move up
      stateinout.RenderShell_movement = 0;
    }
    else if (stateinout.bufferPos == 4 && stateinout.buffer[0] == 'd' && stateinout.buffer[1] == 'o' && stateinout.buffer[2] == 'w' && stateinout.buffer[3] == 'n')
    {
      // Move down
      stateinout.RenderShell_movement = 1;
    }
    else
    {
      hoh_debug("unknown command");

      char *p = "Unknown command";

      for (int loc = 0; *p; loc++, p++)
      {
        stateinout.renderingString[loc] = *p;
        stateinout.renderingStringSize += 1;
      }

      hoh_debug("Rendering String (Unknowm): " << stateinout.renderingString);
    }
    stateinout.IsEnter = true;

    hoh_debug("Rendering string: " << stateinout.renderingString);
    // PRAKHAR MADARCHOD
    hoh_debug("Rendering string size: " << stateinout.renderingStringSize);

    for (int i = 0; i < stateinout.renderingStringSize; i++)
    {
      stateinout.CommandOutput[i] = stateinout.renderingString[i];
    }

    for (int i = 0; i < stateinout.bufferPos; i++)
    {
      stateinout.ShellCommand[i] = stateinout.buffer[i];
    }

    hoh_debug("CMDOUTPUT: " << stateinout.CommandOutput);

    for (int i = 0; i < stateinout.bufferPos; i++)
    {
      stateinout.PreviousCommand[i] = stateinout.buffer[i];
    }
    stateinout.PreviousCommandSize = stateinout.bufferPos;

    // stateinout.PreviousCommand = stateinout.shellCommand;

    char *x = "";
    for (int i = 0; i < stateinout.renderingStringSize; i++)
    {
      stateinout.renderingString[i] = *x;
    }
    stateinout.ShellCommandSize = stateinout.renderingStringSize;

    stateinout.renderingStringSize = 0;

    for (int i = 0; i < stateinout.bufferPos; i++)
    {
      stateinout.buffer[i] = *x;
    }

    /////////////////////////
    stateinout.bufferPos = 0;
    stateinout.renderingStringSize = 0;
    /////////////////////////

    // int i = 0;

    // for (int i = 0; i < stateinout.bufferPos; i++)
    //   // stateinout.out_buffer[stateinout.cursorLine][i] = stateinout.renderingString[i];
    //   stateinout.out_buffer[stateinout.cursorLine][i] = 'p';
    // stateinout.cursorLine++;
    // for (int i = 0; i < stateinout.renderingStringSize; i++)
    //   // stateinout.out_buffer[stateinout.cursorLine][i] = stateinout.renderingString[i];
    //   stateinout.out_buffer[stateinout.cursorLine][i] = 'p';
    // stateinout.cursorLine++;

    stateinout.totalcommands++;
    if (stateinout.totalcommands > 6)
      stateinout.totalcommands = 6;
    int i;
    if (stateinout.totalcommands == 6)
    {
      for (i = 1; i < 6; i++)
      {
        for (int j = 0; j < SHELL_BUFFER_LEN; j++) // hello?
          stateinout.last_commands[i - 1][j] = stateinout.last_commands[i][j];
        for (int j = 0; j < SHELL_BUFFER_LEN; j++)
          stateinout.last_outputs[i - 1][j] = stateinout.last_outputs[i][j];
      }
    }

    for (int j = 0; j < SHELL_BUFFER_LEN; j++)
      stateinout.last_commands[stateinout.totalcommands - 1][j] = stateinout.PreviousCommand[j];
    for (int j = 0; j < SHELL_BUFFER_LEN; j++)
      stateinout.last_outputs[stateinout.totalcommands - 1][j] = stateinout.CommandOutput[j];
  }
  else
  {
    stateinout.IsEnter = false;
    for (int i = 0; i < stateinout.bufferPos; i++)
    {
      stateinout.ShellCommand[i] = stateinout.buffer[i];
    }
    char *x = "";
    for(int i=stateinout.bufferPos;i<SHELL_BUFFER_LEN;i++)
    {
      stateinout.ShellCommand[i] = *x;
    }
    stateinout.ShellCommandSize = stateinout.bufferPos;
    // hoh_debug("Buffer Command: " << stateinout.buffer);
    // hoh_debug("Shell Command: " << stateinout.ShellCommand);
  }
}

//
// shellstate --> renderstate
//
void shell_render(const shellstate_t &shell, renderstate_t &render)
{

  //
  // renderstate. number of keys pressed = shellstate. number of keys pressed
  //
  // renderstate. menu highlighted = shellstate. menu highlighted
  //
  // renderstate. function result = shellstate. output argument
  //
  // etc.
  //
  render.numKeysPressed = shell.numKeysPressed;
  render.IsEnter = shell.IsEnter;
  render.totalcommands = shell.totalcommands;
  if (shell.IsEnter)
  {
    hoh_debug("Shell Enter is "
              << "True");
  }
  for (int j = 0; j < SHELL_BUFFER_SIZE; j++)
    render.curr_command[j] = shell.ShellCommand[j];

  // if (render.IsEnter)
  // {
  // hoh_debug("SR\tTotalcommands:" << render.totalcommands);
  // hoh_debug("SR\tKey Presses:" << shell.numKeysPressed);
  // hoh_debug("SR\tcurrent command:" << shell.ShellCommand);
  // hoh_debug("SR\tcurrent output:" << shell.CommandOutput);
  // hoh_debug("SR\tcurrent output:" << shell.PreviousCommand);
  // hoh_debug("SR: IsEnter"
  //           << "True");
  int i;
  for (i = 0; i < 6; i++)
  {
    for (int j = 0; j < SHELL_BUFFER_LEN; j++) // hello?
      render.last_commands[i][j] = shell.last_commands[i][j];
    for (int j = 0; j < SHELL_BUFFER_LEN; j++)
      render.last_outputs[i][j] = shell.last_outputs[i][j];
  }
  if (render.IsEnter)
    for (int j = 0; j < SHELL_BUFFER_LEN; j++)
      render.curr_command[j] = ' ';
  // }
  // render.IsEnter = false;
  // render.cursorLine = shell.cursorLine;
  // render.cursorPos = shell.cursorPos;
  // render.renderingStringSize = shell.renderingStringSize;
  // render.IsEnter = shell.IsEnter;
  // for (int i = 0; i < shell.renderingStringSize; i++)
  // {
  //   render.renderingString[i] = shell.renderingString[i];
  // }
  // for (int j = 0; j < SHELL_BUFFER_LEN; j++)
  //   render.out_buffer[shell.cursorLine][j] = shell.out_buffer[shell.cursorLine][j];
  // render.out_ready = shell.out_ready;
  // for (int i = 0; i < SHELL_BUFFER_LEN; i++)
  // {
  //   render.buffer[i] = shell.buffer[i];
  // }
  // // render.buffer = shell.buffer;
  // render.bufferPos = shell.bufferPos;
  // render.DisplayMenu = shell.DisplayMenu;
  // pro yaha likh
}

//
// compare a and b
//
bool render_eq(const renderstate_t &a, const renderstate_t &b)
{
  if (a.numKeysPressed == b.numKeysPressed)
    return true;
  return false;
}

static void fillrect(int x0, int y0, int x1, int y1, uint8_t bg, uint8_t fg, int w, int h, addr_t vgatext_base);
static void drawrect(int x0, int y0, int x1, int y1, uint8_t bg, uint8_t fg, int w, int h, addr_t vgatext_base);
static void drawtext(int x, int y, const char *str, int maxw, uint8_t bg, uint8_t fg, int w, int h, addr_t vgatext_base);
static void drawnumberinhex(int x, int y, uint32_t number, int maxw, uint8_t bg, uint8_t fg, int w, int h, addr_t vgatext_base);

//
// Given a render state, we need to write it into vgatext buffer
//
static void writecharxy(int x, int y, uint8_t c, uint8_t bg, uint8_t fg, int w, int h, addr_t vgatext_base)
{
  vgatext::writechar(y * w + x, c, bg, fg, vgatext_base);
  // loc, char,
}
void render(const renderstate_t &state, int w, int h, addr_t vgatext_base)
{
  // this is just an example:
  //
  // Please create your own user interface
  //
  // You may also have simple command line user interface
  // or menu based interface or a combination of both.
  //
  // START HERE
  // hoh_debug("key ye tto be oressed");
  // char curr_command[SHELL_BUFFER_LEN]=;
  // char last_commands[7][SHELL_BUFFER_LEN];
  // char last_outputs[7][SHELL_BUFFER_LEN];
  // int totalcommands = 2;
  hoh_debug("R\tTotal Commands:" << state.totalcommands);
  hoh_debug("R\tKey Presses:" << state.numKeysPressed);
  hoh_debug("R\tcurrent command:" << state.curr_command);
  uint8_t bg = 0, fg = 7;
  uint8_t black = 0;
  const char *p = "KeyPresses: ";
  drawtext(0, 1, p, w, bg, 0xe, w, h, vgatext_base);
  drawnumberinhex(14, 1, state.numKeysPressed, w, bg, 0xe, w, h, vgatext_base);
  int rec[4] = {0, 2, w - 1, 10};
  drawrect(rec[0], rec[1], rec[2], rec[3], bg, 0xb, w, h, vgatext_base);
  int line = 3;
  // hoh_debug("key ye tto be oressed");
  // hoh_debug("------------------------------");
  // if (state.DisplayMenu)
  // {
  const char *p1 = "Menu: ";
  drawtext(1, line++, p1, w, bg, 0x5, w, h, vgatext_base);
  const char *p2 = "1: echo <text>";
  drawtext(1, line++, p2, w, bg, 0x5, w, h, vgatext_base);
  const char *p3 = "2: fibonacci <num>";
  drawtext(1, line++, p3, w, bg, 0x5, w, h, vgatext_base);
  const char *p4 = "3: factorial <num> {Max Val:16}";
  drawtext(1, line++, p4, w, bg, 0x5, w, h, vgatext_base);
  const char *p5 = "4: rigtest <num> {Max Val:10}";
  drawtext(1, line++, p5, w, bg, 0x5, w, h, vgatext_base);
  const char *p6 = "5: exit ";
  drawtext(1, line++, p6, w, bg, 0x5, w, h, vgatext_base);
  line = 11;
  // hoh_debug("1------------------------------");
  const char *dollar = "os-user@oslab:$";
  uint16_t offset = sizeof(dollar) * 4 + 1;
  offset = 17; // For testing
  for (int i = 0; i < state.totalcommands; i++)
  {
    // hoh_debug("2------------------------------");
    hoh_debug(state.last_commands[i]);
    drawtext(1, line, dollar, w, bg, 0x2, w, h, vgatext_base);
    for (int j = 0; j < SHELL_BUFFER_LEN; j++)
      writecharxy(offset + j, line, state.last_commands[i][j], bg, fg, w, h, vgatext_base);
    line++;
    drawtext(1, line, "> ", w, bg, fg, w, h, vgatext_base);
    for (int j = 0; j < SHELL_BUFFER_LEN; j++)
      writecharxy(3 + j, line, state.last_outputs[i][j], bg, fg, w, h, vgatext_base);
    line++;
  }
  drawtext(1, line, dollar, w, bg, 0x2, w, h, vgatext_base);
  for (int j = 0; j < SHELL_BUFFER_LEN; j++)
    writecharxy(offset + j, line, state.curr_command[j], bg, fg, w, h, vgatext_base);
  line++;
} //
//
// helper functions
//
//

static void fillrect(int x0, int y0, int x1, int y1, uint8_t bg, uint8_t fg, int w, int h, addr_t vgatext_base)
{
  for (int y = y0; y < y1; y++)
  {
    for (int x = x0; x < x1; x++)
    {
      writecharxy(x, y, 0, bg, fg, w, h, vgatext_base);
    }
  }
}

static void drawrect(int x0, int y0, int x1, int y1, uint8_t bg, uint8_t fg, int w, int h, addr_t vgatext_base)
{

  writecharxy(x0, y0, 0xc9, bg, fg, w, h, vgatext_base);
  writecharxy(x1 - 1, y0, 0xbb, bg, fg, w, h, vgatext_base);
  writecharxy(x0, y1 - 1, 0xc8, bg, fg, w, h, vgatext_base);
  writecharxy(x1 - 1, y1 - 1, 0xbc, bg, fg, w, h, vgatext_base);

  for (int x = x0 + 1; x + 1 < x1; x++)
  {
    writecharxy(x, y0, 0xcd, bg, fg, w, h, vgatext_base);
  }

  for (int x = x0 + 1; x + 1 < x1; x++)
  {
    writecharxy(x, y1 - 1, 0xcd, bg, fg, w, h, vgatext_base);
  }

  for (int y = y0 + 1; y + 1 < y1; y++)
  {
    writecharxy(x0, y, 0xba, bg, fg, w, h, vgatext_base);
  }

  for (int y = y0 + 1; y + 1 < y1; y++)
  {
    writecharxy(x1 - 1, y, 0xba, bg, fg, w, h, vgatext_base);
  }
}

static void drawtext(int x, int y, const char *str, int maxw, uint8_t bg, uint8_t fg, int w, int h, addr_t vgatext_base)
{
  for (int i = 0; i < maxw; i++)
  {
    writecharxy(x + i, y, str[i], bg, fg, w, h, vgatext_base);
    if (!str[i])
    {
      break;
    }
  }
}

static void drawnumberinhex(int x, int y, uint32_t number, int maxw, uint8_t bg, uint8_t fg, int w, int h, addr_t vgatext_base)
{
  enum
  {
    max = sizeof(uint32_t) * 2 + 1
  };
  char a[max];
  for (int i = 0; i < max - 1; i++)
  {
    a[max - 1 - i - 1] = hex2char(number % 16);
    number = number / 16;
  }
  a[max - 1] = '\0';

  drawtext(x, y, a, maxw, bg, fg, w, h, vgatext_base);
}

// x ------> max w
// |
// |
// |
// |
// y

/*
1. cureent line oe kay displ
2. last executed command
3. oyututy last


buffer
1. step         : input lega and parse: returns 3 object
twtwefsd3. render       :
*/

/*
MADARCHOD:
1. return error string if error
2. return


*/