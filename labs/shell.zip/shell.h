#pragma once
#include "util/config.h"
#include "util/debug.h"

#define SHELL_BUFFER_SIZE 100
#define SHELL_BUFFER_LEN 32
#define AVAILABLE_FUNCTIONS 100

struct shellstate_t
{
    uint32_t numKeysPressed = 0;
    char buffer[SHELL_BUFFER_SIZE];
    int bufferSize;
    int bufferPos;
    int cursorPos;
    int cursorLine;
    char *KeysPresses[100];

    char *keys[100];
    char *scancode[100];
    char *availableFunctions[AVAILABLE_FUNCTIONS];
    bool IsEnter = false;
    int RenderShell_movement = -1; // 0 for up and 1 for down
    char renderingString[100];
    int renderingStringSize = 0;
    bool DisplayMenu = true;
    int totalcommands = 0;
    char ShellCommand[100];
    char CommandOutput[100];
    char PreviousCommand[100];

    int PreviousCommandSize;
    int ShellCommandSize;
    int CommandOutputSize;
    /*char *ShellCommand;
    char *CommandOutput;
    char *PreviousCommand;*/

    void increment_key_presses()
    {
        numKeysPressed++;
    }
    char *scancode_to_key(uint8_t scankey);
    int key_to_scancode(uint8_t key);
    bool out_ready = false;
    char out_buffer[SHELL_BUFFER_SIZE][SHELL_BUFFER_LEN];
    int out_buffer_size = 0;
    char curr_command[SHELL_BUFFER_LEN];
    char last_commands[7][SHELL_BUFFER_LEN];
    char last_outputs[7][SHELL_BUFFER_LEN];
};

struct renderstate_t
{
    int cursorPos;
    int cursorLine;
    int bufferPos = 0;
    bool IsEnter = false;
    char renderingString[100];
    char buffer[SHELL_BUFFER_SIZE];
    int renderingStringSize = 0;
    bool DisplayMenu = true;
    char out_buffer[SHELL_BUFFER_SIZE][SHELL_BUFFER_LEN];
    bool out_ready = false;
    uint32_t numKeysPressed = 0;
    int totalcommands;
    char curr_command[SHELL_BUFFER_LEN];
    char last_commands[7][SHELL_BUFFER_LEN];
    char last_outputs[7][SHELL_BUFFER_LEN];
    ///////////////////////////
};

void shell_init(shellstate_t &state);
void shell_update(uint8_t scankey, shellstate_t &stateinout);
void shell_step(shellstate_t &stateinout);
void shell_render(const shellstate_t &shell, renderstate_t &render);

bool render_eq(const renderstate_t &a, const renderstate_t &b);
void render(const renderstate_t &state, int w, int h, addr_t display_base);
